
// Let's practice some Math!

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {

        // Ideen: goodWords und badWords jeweils ein Enum daraus machen.
        ArrayList<String> goodWords = new ArrayList<>();
        ArrayList<String> badWords = new ArrayList<>();
        goodWords.add("Wow, even Einstein would be asking for tips from you!");
        goodWords.add("Wow, you could out-calculate a calculator!");
        goodWords.add("Wow, simply amazing!");
        goodWords.add("Wow, your math skills are impressive!");
        goodWords.add("Wow, you are definitely a math professor!");
        badWords.add("Oops, just bring your brain back to reality!");
        badWords.add("Oops, looks like your math skills took a little vacation!");
        badWords.add("Oops, hopefully, you are not the worst!");
        badWords.add("Oops, your math skills are miserable!");
        badWords.add("Oops, Pythagoras just rolled over in his grave!");

        Scanner sc = new Scanner(System.in);
        System.out.println("Hi, my friend. What is your name?");
        String userName = sc.nextLine();

        System.out.println(userName + ", press: \n- 1 to practice math with the number from 0 to 20.\n- 2 to practice math with the number from 0 to 100.");
        String input = sc.nextLine();
        int difficultyLevel = 0;
        try
        {
            difficultyLevel = Integer.parseInt(input);
        }
        catch(Exception exception)
        {
            System.out.println(exception.getMessage());
        }

        System.out.println("Press `+` to add or `-` to subtract.");
        String operator = sc.nextLine();


        for (int i = 0; i < 5; i++)
        {
            if (difficultyLevel == 1 && operator.equals("+"))
            {
                Random random = new Random();
                int randomDigit1 = random.nextInt(21);
                int randomDigit2 = random.nextInt(21);
                int result = randomDigit1 + randomDigit2;
                System.out.println(randomDigit1 + operator + randomDigit2 + "=");

                input = sc.nextLine();
                int userResult = 0;
                try
                {
                    userResult = Integer.parseInt(input);
                }
                catch(Exception ex)
                {
                    System.out.println(ex.getMessage());
                }

                if (userResult == result) {
                    int randomGoodWord = random.nextInt(goodWords.size());
                    System.out.println(goodWords.get(randomGoodWord));

                } else {
                    int randomBadWord = random.nextInt(badWords.size());
                    System.out.println(badWords.get(randomBadWord));
                }
            }
            if (difficultyLevel == 1 && operator.equals("-"))
            {
                Random random = new Random();
                int randomDigit1 = random.nextInt(21);
                int randomDigit2 = random.nextInt(randomDigit1);
                int result = randomDigit1 - randomDigit2;
                if(randomDigit1>randomDigit2)
                {
                    System.out.println(randomDigit1 + operator + randomDigit2 + "=");
                    int userResult = 0;
                    input = sc.nextLine();

                    try
                    {
                        userResult = Integer.parseInt(input);
                    }
                    catch(Exception ex)
                    {
                        ex.getMessage();
                    }

                    if (userResult == result) {
                        int randomGoodWord = random.nextInt(goodWords.size());
                        System.out.println(goodWords.get(randomGoodWord));
                    } else {
                        int randomBadWord = random.nextInt(badWords.size());
                        System.out.println(badWords.get(randomBadWord));
                    }
                }
            }
            if (difficultyLevel == 2 && operator.equals("+"))
            {
                Random random = new Random();
                int randomDigit1 = random.nextInt(101);
                int randomDigit2 = random.nextInt(101);
                int result = randomDigit1 + randomDigit2;
                System.out.println(randomDigit1 + operator + randomDigit2 + "=");

                int userResult = 0;
                input = sc.nextLine();

                try
                {
                    userResult = Integer.parseInt(input);
                }
                catch(Exception ex)
                {
                    ex.getMessage();
                }

                if (userResult == result) {
                    int randomGoodWord = random.nextInt(goodWords.size());
                    System.out.println(goodWords.get(randomGoodWord));
                } else {
                    int randomBadWord = random.nextInt(badWords.size());
                    System.out.println(badWords.get(randomBadWord));
                }
            }
            if (difficultyLevel == 2 && operator.equals("-")) {
                Random random = new Random();
                int randomDigit1 = random.nextInt(101);
                int randomDigit2 = random.nextInt(randomDigit1);
                int result = randomDigit1 - randomDigit2;
                System.out.println(randomDigit1 + operator + randomDigit2 + "=");

                int userResult = sc.nextInt();
                if (userResult == result) {
                    int randomGoodWord = random.nextInt(goodWords.size());
                    System.out.println(goodWords.get(randomGoodWord));
                } else {
                    int randomBadWord = random.nextInt(badWords.size());
                    System.out.println(badWords.get(randomBadWord));
                }
            }
        }
        System.out.println("\nThat's it for today. Have a nice day!");
    }
}
